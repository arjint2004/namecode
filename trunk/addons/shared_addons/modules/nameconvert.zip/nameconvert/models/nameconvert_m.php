<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
/**
 * This is a nameconvert module for PyroCMS
 *
 * @author 		Jerel Unruh - PyroCMS Dev Team
 * @website		http://unruhdesigns.com
 * @package 	PyroCMS
 * @subpackage 	Nameconvert Module
 */
class Nameconvert_m extends MY_Model {

	public function __construct()
	{		
		parent::__construct();
		
	}
	
	
	//IDENTIFIER CAT
	public function get_count_identifierCat()
	{

		$q=$this->db->query('SELECT COUNT(*) FROM default_kategori_indikator');
		//echo $this->db->last_query();die();
		$cnt=$q->result_array();
		return $cnt[0]['COUNT(*)'];
	}
	public function get_identifierCatById($id=0)
	{
		$q=$this->db->query('SELECT * FROM default_kategori_indikator WHERE id='.$id.' ');
		//echo $this->db->last_query();die();
		return $q->result_array();
	}
	public function get_identifierCat($field="*",$limit=array())
	{
		$q=$this->db->query('SELECT * FROM default_kategori_indikator WHERE active=1  LIMIT '.$limit[1].','.$limit[0].'');
		//echo $this->db->last_query();die();
		return $q->result_array();
	}
	//IDENTIFIER NAME
	public function get_count_identifierName()
	{

		$q=$this->db->query('SELECT COUNT(*) FROM default_indikator');
		//echo $this->db->last_query();die();
		$cnt=$q->result_array();
		return $cnt[0]['COUNT(*)'];
	}
	public function get_identifierNameById($id=0)
	{
		$q=$this->db->query('SELECT * FROM default_indikator WHERE id='.$id.' ');
		//echo $this->db->last_query();die();
		return $q->result_array();
	}
	public function get_identifierName($field="*",$limit=array())
	{
		$q=$this->db->query('SELECT * FROM default_indikator WHERE active=1  LIMIT '.$limit[1].','.$limit[0].'');
		//echo $this->db->last_query();die();
		return $q->result_array();
	}
	
	//ITEMS
	public function create($input)
	{
		$to_insert = array(
			'name' => $input['name'],
			'slug' => $this->_check_slug($input['slug'])
		);

		return $this->db->insert('nameconvert', $to_insert);
	}

	public function _check_slug($slug)
	{
		$slug = strtolower($slug);
		$slug = preg_replace('/\s+/', '-', $slug);

		return $slug;
	}
}
