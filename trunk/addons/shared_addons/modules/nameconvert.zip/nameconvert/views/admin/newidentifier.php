<section class="title">
	<h4>Identifier Category</h4>
</section>
<section class="item">
	<div class="content">
		<?php echo form_open_multipart($this->uri->uri_string(), 'class="crud"'); 
		if(!empty($data)){
		?>
		<input type="hidden" name="id" required value="<?=@$data[0]['id']?>"/>
		<? } ?>
		<table class="zebra-striped">
			<tr>
				<th style="text-align:center;">No</th>
				<th style="text-align:center;">Name</th>
				<th style="text-align:center;">Origin</th>
				<th style="text-align:center; border-left:1px solid #ccc;"">Name</th>
				<th style="text-align:center;">Origin</th>
			</tr>
			<? for($i=1;$i<=10;$i++){?>
			<tr>
				<td style="text-align:center;"><?=$i?></td>
				<td style="text-align:center;"><input type="text" name="nama[]"  /></td>
				<td style="text-align:center;"><input type="text" name="origin[]"  /></td>
				<td  style="text-align:center; border-left:1px solid #ccc;"><input type="text" name="nama[]"  /></td>
				<td style="text-align:center;"><input type="text" name="origin[]"  /></td>
			</tr>
			<? } ?>
			
		</table>
		<div class="buttons" style="text-align:center;">		
			<button class="btn blue" value="save" name="btnAction" type="submit">
				<span>Save</span>
			</button>						
		<a class="btn gray cancel" href="<?=base_url('admin/nameconvert/identycategory');?>">Cancel</a>
		</div>
		<?php echo form_close(); ?>
	</div>
</section>