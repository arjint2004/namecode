<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
/**
 * This is a nameconvert module for PyroCMS
 *
 * @author 		Jerel Unruh - PyroCMS Dev Team
 * @website		http://unruhdesigns.com
 * @package 	PyroCMS
 * @subpackage 	Nameconvert Module
 */
class Admin extends Admin_Controller
{
	protected $section = 'Name Identifier';

	public function __construct()
	{
		parent::__construct();

		// Load all the required classes
		$this->load->model('nameconvert_m');
		$this->load->library('form_validation');
		$this->lang->load('nameconvert');

		// Set the validation rules
		$this->item_validation_rules = array(
			array(
				'field' => 'name',
				'label' => 'Name',
				'rules' => 'trim|max_length[100]|required'
			),
			array(
				'field' => 'slug',
				'label' => 'Slug',
				'rules' => 'trim|max_length[100]|required'
			)
		);

		// We'll set the partials and metadata here since they're used everywhere
		$this->template->append_js('module::admin.js')
						->append_css('module::admin.css');
	}

	/**
	 * List all items
	 */
	public function index()
	{
		// here we use MY_Model's get_all() method to fetch everything
		$items = $this->nameconvert_m->get_all();

		// Build the view with nameconvert/views/admin/items.php
		$this->template
			->title($this->module_details['name'])
			->set('items', $items)
			->build('admin/items');
	}

	public function create()
	{
		// Set the validation rules from the array above
		$this->form_validation->set_rules($this->item_validation_rules);

		// check if the form validation passed
		if ($this->form_validation->run())
		{
			// See if the model can create the record
			if ($this->nameconvert_m->create($this->input->post()))
			{
				// All good...
				$this->session->set_flashdata('success', lang('nameconvert.success'));
				redirect('admin/nameconvert');
			}
			// Something went wrong. Show them an error
			else
			{
				$this->session->set_flashdata('error', lang('nameconvert.error'));
				redirect('admin/nameconvert/create');
			}
		}
		
		$nameconvert = new stdClass;
		foreach ($this->item_validation_rules as $rule)
		{
			$nameconvert->{$rule['field']} = $this->input->post($rule['field']);
		}

		// Build the view using nameconvert/views/admin/form.php
		$this->template
			->title($this->module_details['name'], lang('nameconvert.new_item'))
			->set('nameconvert', $nameconvert)
			->build('admin/form');
	}
	
	public function edit($id = 0)
	{
		$nameconvert = $this->nameconvert_m->get($id);

		// Set the validation rules from the array above
		$this->form_validation->set_rules($this->item_validation_rules);

		// check if the form validation passed
		if ($this->form_validation->run())
		{
			// get rid of the btnAction item that tells us which button was clicked.
			// If we don't unset it MY_Model will try to insert it
			unset($_POST['btnAction']);
			
			// See if the model can create the record
			if ($this->nameconvert_m->update($id, $this->input->post()))
			{
				// All good...
				$this->session->set_flashdata('success', lang('nameconvert.success'));
				redirect('admin/nameconvert');
			}
			// Something went wrong. Show them an error
			else
			{
				$this->session->set_flashdata('error', lang('nameconvert.error'));
				redirect('admin/nameconvert/create');
			}
		}

		// Build the view using nameconvert/views/admin/form.php
		$this->template
			->title($this->module_details['name'], lang('nameconvert.edit'))
			->set('nameconvert', $nameconvert)
			->build('admin/form');
	}
	
	public function delete($id = 0)
	{
		// make sure the button was clicked and that there is an array of ids
		if (isset($_POST['btnAction']) AND is_array($_POST['action_to']))
		{
			// pass the ids and let MY_Model delete the items
			$this->nameconvert_m->delete_many($this->input->post('action_to'));
		}
		elseif (is_numeric($id))
		{
			// they just clicked the link so we'll delete that one
			$this->nameconvert_m->delete($id);
		}
		redirect('admin/nameconvert');
	}
	
	
	
	
	
	private function getdataexcell($file=null){
		if($_FILES){
			// Load the spreadsheet reader library
			$this->load->library('excel_reader');
			// Set output Encoding.
			$this->excel_reader->setOutputEncoding('CP1251');
			$file =  $_FILES['file_excell']['tmp_name'] ;
			$this->excel_reader->read($file);
			error_reporting(E_ALL ^ E_NOTICE);
			// Sheet 1
			$data = $this->excel_reader->sheets[0] ;
			return $data;
		}
		return false;
	 }
	//CATEGORY IDENTIFIER
	
	public function identycategory()
	{
		
		if(!empty($_POST['idx'])){
			//pr($_POST);die();
			foreach($_POST['idx'] as $id){
				$this->db->query('DELETE FROM default_kategori_indikator WHERE id='.$id.'');
			}
		}
		$this->load->model('ihs/nameconvert_m');
	
		$total_rows =$this->nameconvert_m->get_count_identifierCat();
		// Create pagination links
		$pagination = create_pagination('admin/nameconvert/identycategory', $total_rows,Settings::get('records_per_page'),4);

		$data = $this->nameconvert_m->get_identifierCat('*',array($pagination['limit'], $pagination['offset']));

		$this->input->is_ajax_request() and $this->template->set_layout(false);
		
		$this->template
			->title('Category Identifier')
			->set('data', $data)
			->set('pagination', $pagination)
			->build('admin/identycategory');
	}
	public function deleteidentycategory($id=0)
	{
		if(isset($id)){
			$this->db->where('id',$id);
			if($this->db->delete('kategori_indikator')){
				redirect('admin/nameconvert/identycategory');
				die();			
			}
		}
		
	}
	public function editidentycategory($id=0)
	{
		$this->load->model('ihs/nameconvert_m');
		if(isset($_POST['id'])){
			$data_update=array(
						'kategori'=>$_POST['kategori'],
						'keterangan'=>$_POST['keterangan'],
			);
			$this->db->where('id',$id);
			if($this->db->update('kategori_indikator',$data_update)){
				redirect('admin/nameconvert/identycategory');
				die();
			}
		}
		$data=$this->nameconvert_m->get_identifierCatById($id);
		
		$this->template
			->title('Edit Category Identifier')
			->set('data', $data)
			->build('admin/newcategory');
	}
	public function newcategory()
	{
		if(isset($_POST['kategori'])){
			$data_insert=array('kategori'=>$_POST['kategori'],'keterangan'=>$_POST['keterangan'],'active'=>1);
			if($this->db->insert('kategori_indikator',$data_insert)){
				redirect('admin/nameconvert/identycategory');
			}
		}
		
		$this->template
			->title($this->module_details['name'])
			->build('admin/newcategory');
	}
	public function activateidentycategory($id=0,$aktif=null)
	{
		if($aktif==0){
			$data_update=array('active'=>$aktif);
		}elseif($aktif==1){
			$data_update=array('active'=>$aktif);
		}
		//pr($data_update);
		$this->db->where('id',$aktif);
		if($this->db->update('kategori_indikator',$data_update)){
			redirect('admin/nameconvert/identycategory');
		}
	}
	public function importcategory()
	{
		if(isset($_FILES['file_excell'])){
			$data=$this->getdataexcell();
			unset($data['cells'][1]);
			//pr($data);die();
			foreach($data['cells'] as $baris=>$dataimp){
				$insert_data=array(
					'kategori'=>$dataimp[1],
					'keterangan'=>$dataimp[2],
					'active'=>$dataimp[3]
				);
				if($this->db->insert('kategori_indikator',$insert_data)){
					unset($insert_data);
				}
			}
			redirect('admin/nameconvert/identycategory');
		}
		
		$this->template
			->title($this->module_details['name'])
			->build('admin/importcategory');
	}
	
	//NAME GROUP
	
	public function identyname()
	{
		
		if(!empty($_POST['idx'])){
			//pr($_POST);die();
			foreach($_POST['idx'] as $id){
				$this->db->query('DELETE FROM default_indikator WHERE id='.$id.'');
			}
		}
		$this->load->model('ihs/nameconvert_m');
	
		$total_rows =$this->nameconvert_m->get_count_identifierName();
		// Create pagination links
		$pagination = create_pagination('admin/nameconvert/identyname', $total_rows,Settings::get('records_per_page'),4);

		$data = $this->nameconvert_m->get_identifierName('*',array($pagination['limit'], $pagination['offset']));
		//pr($data);die();
		$this->input->is_ajax_request() and $this->template->set_layout(false);
		
		$this->template
			->title('Identifier Name')
			->set('data', $data)
			->set('pagination', $pagination)
			->build('admin/identyname');
	}
	
	public function newidentifier()
	{
		if(isset($_POST['nama'])){
			//pr($_POST);die();
			foreach($_POST['nama'] as $idx=>$nama){
				$data_insert=array('nama'=>$nama,'origin'=>$_POST['origin'][$idx],'active'=>1);
				$this->db->insert('indikator',$data_insert);
			}
			redirect('admin/nameconvert/identyname');
		}
		
		$this->template
			->title('Add Identifier Name')
			->build('admin/newidentifier');
	}
	public function editidentyname($id=0)
	{
		$this->load->model('ihs/nameconvert_m');
		if(isset($_POST['id'])){
			$data_update=array(
						'nama'=>$_POST['nama'],
						'origin'=>$_POST['origin'],
			);
			$this->db->where('id',$id);
			if($this->db->update('indikator',$data_update)){
				redirect('admin/nameconvert/identyname');
				die();
			}
		}
		$data=$this->nameconvert_m->get_identifierNameById($id);
		
		$this->template
			->title('Edit Category Identifier')
			->set('data', $data)
			->build('admin/nameidentform');
	}
	
	public function deleteidentyname($id=0)
	{
		if(isset($id)){
			$this->db->where('id',$id);
			if($this->db->delete('indikator')){
				redirect('admin/nameconvert/identyname');
				die();			
			}
		}
		
	}
	
	public function importidentifier()
	{
		if(isset($_FILES['file_excell'])){
			$data=$this->getdataexcell();
			unset($data['cells'][1]);
			//pr($data);die();
			foreach($data['cells'] as $baris=>$dataimp){
				$insert_data=array(
					'nama'=>$dataimp[1],
					'origin'=>$dataimp[2],
					'active'=>1
				);
				if($this->db->insert('indikator',$insert_data)){
					unset($insert_data);
				}
			}
			redirect('admin/nameconvert/identyname');
		}
		
		$this->template
			->title($this->module_details['name'])
			->build('admin/importidentifier');
	}
	//NAME LIST
	
	//IMPORT
	
	//EXPORT
	
	//STATISTIC
}
