<?php
//messages
$lang['nameconvert:success']			=	'It worked';
$lang['nameconvert:error']			=	'It didn\'t work';
$lang['nameconvert:no_items']		=	'No Items';

//page titles
$lang['nameconvert:create']			=	'Create Item';

//labels
$lang['nameconvert:name']			=	'Name';
$lang['nameconvert:slug']			=	'Slug';
$lang['nameconvert:manage']			=	'Manage';
$lang['nameconvert:item_list']		=	'Item List';
$lang['nameconvert:view']			=	'View';
$lang['nameconvert:edit']			=	'Edit';
$lang['nameconvert:delete']			=	'Delete';

//buttons
$lang['nameconvert:custom_button']	=	'Custom Button';
$lang['nameconvert:items']			=	'Items';
?>